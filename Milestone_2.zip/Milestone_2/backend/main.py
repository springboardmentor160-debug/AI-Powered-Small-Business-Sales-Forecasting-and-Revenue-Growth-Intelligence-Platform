"""
FastAPI Backend Application Entrypoint for Milestone 2 (MarketMind AI)
"""

import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from .routes import router as api_router

app = FastAPI(
    title="MarketMind AI - Milestone 2 Sales Forecasting & Customer Intelligence API",
    version="2.0.0",
    description="Backend API serving empirical customer segmentation, time-series sales/revenue forecasting, model metrics, and business reports."
)

# Enable CORS for local dashboard development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount API router
app.include_router(api_router)

# Mount static frontend directory
FRONTEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend"))

if os.path.exists(FRONTEND_DIR):
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

    @app.get("/", include_in_schema=False)
    def read_root():
        index_file = os.path.join(FRONTEND_DIR, "index.html")
        if os.path.exists(index_file):
            return FileResponse(index_file)
        return {"message": "MarketMind AI Milestone 2 Backend API is running."}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("Milestone_2.backend.main:app", host="127.0.0.1", port=8000, reload=True)
