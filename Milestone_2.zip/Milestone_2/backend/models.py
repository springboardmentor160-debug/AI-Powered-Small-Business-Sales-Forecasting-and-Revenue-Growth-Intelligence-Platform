"""
Pydantic Data Models for Milestone 2 API
"""

from pydantic import BaseModel
from typing import List, Dict, Any, Optional

class OverviewKPI(BaseModel):
    total_sales: float
    total_customers: int
    total_orders: int
    best_forecasting_model: str
    best_model_rmse: float
    top_customer_segment: str

class ClusterSummaryItem(BaseModel):
    segment_name: str
    cluster_id: int
    customer_count: int
    pct_customers: float
    total_sales: float
    pct_sales: float
    mean_recency_days: float
    mean_frequency_orders: float
    mean_monetary_sales: float
    mean_order_value: float
    mean_discount_rate: float

class CustomerItem(BaseModel):
    customer_id: str
    customer_name: str
    orig_segment: str
    region: str
    recency_days: float
    frequency_orders: int
    monetary_sales: float
    avg_order_value: float
    total_profit: float
    avg_discount: float
    kmeans_cluster: int
    hierarchical_cluster: int
    segment_name: str
