"""
API Route Handlers for Milestone 2 Backend
"""

import os
import json
import pandas as pd
from fastapi import APIRouter, HTTPException
from typing import Dict, Any, List

router = APIRouter(prefix="/api")

# Base paths
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")
DATA_DIR = os.path.join(BASE_DIR, "data")

@router.get("/overview")
def get_overview() -> Dict[str, Any]:
    seg_json_path = os.path.join(OUTPUTS_DIR, "segmentation", "segmentation_metrics.json")
    fcst_json_path = os.path.join(OUTPUTS_DIR, "forecasting", "model_metrics.json")
    time_series_path = os.path.join(DATA_DIR, "processed", "time_series_sales.csv")

    if not os.path.exists(seg_json_path) or not os.path.exists(fcst_json_path):
        raise HTTPException(status_code=404, detail="Model output metrics not found. Run ML pipelines first.")

    seg_metrics = json.load(open(seg_json_path))
    fcst_metrics = json.load(open(fcst_json_path))

    df_ts = pd.read_csv(time_series_path)
    total_sales = float(df_ts['y'].sum())
    total_orders = int(df_ts['order_id'].sum()) if 'order_id' in df_ts.columns else len(df_ts)

    best_model = fcst_metrics.get("best_performing_model", "Prophet")
    best_rmse = fcst_metrics["model_metrics"][best_model]["RMSE"]

    # Top segment by sales share
    seg_dist = seg_metrics.get("segment_distribution", {})
    top_seg = max(seg_dist.keys(), key=lambda k: seg_dist[k]["total_sales"]) if seg_dist else "N/A"

    return {
        "total_sales": round(total_sales, 2),
        "total_customers": seg_metrics["total_customers"],
        "total_orders": total_orders,
        "best_forecasting_model": best_model,
        "best_model_rmse": best_rmse,
        "top_customer_segment": top_seg
    }

@router.get("/segmentation/summary")
def get_segmentation_summary() -> Dict[str, Any]:
    seg_json_path = os.path.join(OUTPUTS_DIR, "segmentation", "segmentation_metrics.json")
    summary_csv_path = os.path.join(OUTPUTS_DIR, "segmentation", "cluster_summary.csv")

    if not os.path.exists(seg_json_path):
        raise HTTPException(status_code=404, detail="Segmentation metrics not found.")

    metrics = json.load(open(seg_json_path))
    summary_df = pd.read_csv(summary_csv_path) if os.path.exists(summary_csv_path) else None

    return {
        "metrics": metrics,
        "cluster_summary": summary_df.to_dict(orient="records") if summary_df is not None else []
    }

@router.get("/segmentation/customers")
def get_segmentation_customers(limit: int = 100, segment: str = None) -> Dict[str, Any]:
    cust_csv_path = os.path.join(OUTPUTS_DIR, "segmentation", "customer_segments.csv")
    if not os.path.exists(cust_csv_path):
        raise HTTPException(status_code=404, detail="Customer segments CSV not found.")

    df = pd.read_csv(cust_csv_path)
    if segment:
        df = df[df['segment_name'].str.lower() == segment.lower()]

    total_count = len(df)
    df_slice = df.head(limit)
    return {
        "total_count": total_count,
        "returned_count": len(df_slice),
        "customers": df_slice.to_dict(orient="records")
    }

@router.get("/forecasting/historical")
def get_forecasting_historical() -> Dict[str, Any]:
    time_series_path = os.path.join(DATA_DIR, "processed", "time_series_sales.csv")
    if not os.path.exists(time_series_path):
        raise HTTPException(status_code=404, detail="Historical time series not found.")

    df = pd.read_csv(time_series_path)
    return {
        "records_count": len(df),
        "data": df.to_dict(orient="records")
    }

@router.get("/forecasting/predictions")
def get_forecasting_predictions() -> Dict[str, Any]:
    comb_path = os.path.join(OUTPUTS_DIR, "forecasting", "combined_forecasts.csv")
    if not os.path.exists(comb_path):
        raise HTTPException(status_code=404, detail="Combined forecasts CSV not found.")

    df = pd.read_csv(comb_path)
    # Fill NaN values with None for clean JSON serialization
    df = df.where(pd.notnull(df), None)
    return {
        "records_count": len(df),
        "data": df.to_dict(orient="records")
    }

@router.get("/forecasting/metrics")
def get_forecasting_metrics() -> Dict[str, Any]:
    fcst_json_path = os.path.join(OUTPUTS_DIR, "forecasting", "model_metrics.json")
    if not os.path.exists(fcst_json_path):
        raise HTTPException(status_code=404, detail="Model metrics JSON not found.")

    return json.load(open(fcst_json_path))

@router.get("/reports/{report_name}")
def get_report(report_name: str) -> Dict[str, Any]:
    valid_names = {
        "segmentation": "segmentation_report.md",
        "forecasting": "forecasting_report.md",
        "model_evaluation": "model_evaluation_report.md"
    }
    if report_name not in valid_names:
        raise HTTPException(status_code=400, detail=f"Invalid report name. Choose from {list(valid_names.keys())}")

    filepath = os.path.join(OUTPUTS_DIR, "reports", valid_names[report_name])
    if not os.path.exists(filepath):
        raise HTTPException(status_code=404, detail="Report file not found.")

    content = open(filepath, "r", encoding="utf-8").read()
    return {
        "report_name": report_name,
        "filename": valid_names[report_name],
        "content": content
    }
