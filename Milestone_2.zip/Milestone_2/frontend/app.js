/**
 * MarketMind AI — Milestone 2 Dashboard Logic
 */

const API_BASE = '/api';

// Global state
let overviewData = null;
let segSummaryData = null;
let fcstPredictionsData = null;
let fcstMetricsData = null;
let currentForecastModel = 'Prophet';

// Chart instances
let charts = {};

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    loadDashboardData();

    document.getElementById('btn-refresh').addEventListener('click', loadDashboardData);
    document.getElementById('segment-filter').addEventListener('change', handleSegmentFilter);

    // Model forecast toggle buttons
    document.querySelectorAll('.btn-model').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.btn-model').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentForecastModel = btn.dataset.model;
            renderForecastChart();
        });
    });

    // Report links
    document.querySelectorAll('.report-link').forEach(link => {
        link.addEventListener('click', () => {
            document.querySelectorAll('.report-link').forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            loadReport(link.dataset.report);
        });
    });
});

/* Navigation */
function initNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const tabPanes = document.querySelectorAll('.tab-pane');
    const pageTitle = document.getElementById('page-title');
    const pageSubtitle = document.getElementById('page-subtitle');

    const titles = {
        overview: { title: 'Dashboard Overview', subtitle: 'Real-Time Business Intelligence & AI Forecasting Insights' },
        segmentation: { title: 'Customer Segmentation', subtitle: 'K-Means & Hierarchical Clustering Behavioral Analysis' },
        forecasting: { title: 'Sales & Revenue Forecasting', subtitle: '12-Month Future Projections (Prophet vs XGBoost vs Random Forest)' },
        evaluation: { title: 'Model Evaluation & Benchmark', subtitle: 'Quantitative Error & Accuracy Comparison (MAE, RMSE, R²)' },
        reports: { title: 'Business Reports & Strategic Recommendations', subtitle: 'AI Generated Analytical Reports & Operational Directives' }
    };

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const tab = item.dataset.tab;
            navItems.forEach(i => i.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));

            item.classList.add('active');
            document.getElementById(`tab-${tab}`).classList.add('active');

            if (titles[tab]) {
                pageTitle.textContent = titles[tab].title;
                pageSubtitle.textContent = titles[tab].subtitle;
            }

            if (tab === 'reports') {
                loadReport('segmentation');
            }
        });
    });
}

/* Master Data Loader */
async function loadDashboardData() {
    try {
        await Promise.all([
            fetchOverview(),
            fetchSegmentationSummary(),
            fetchCustomerDirectory(),
            fetchForecastingPredictions(),
            fetchForecastingMetrics()
        ]);
        console.log('All Milestone 2 dashboard data loaded successfully!');
    } catch (err) {
        console.error('Error loading dashboard data:', err);
    }
}

/* Fetch Overview KPIs */
async function fetchOverview() {
    const res = await fetch(`${API_BASE}/overview`);
    overviewData = await res.json();

    document.getElementById('kpi-total-sales').textContent = `$${overviewData.total_sales.toLocaleString('en-US', {minimumFractionDigits: 2})}`;
    document.getElementById('kpi-total-customers').textContent = overviewData.total_customers.toLocaleString();
    document.getElementById('kpi-best-model').textContent = overviewData.best_forecasting_model;
    document.getElementById('kpi-best-rmse').textContent = `RMSE: $${overviewData.best_model_rmse.toLocaleString('en-US', {minimumFractionDigits: 2})}`;
    document.getElementById('kpi-top-segment').textContent = overviewData.top_customer_segment;
}

/* Fetch Segmentation Summary */
async function fetchSegmentationSummary() {
    const res = await fetch(`${API_BASE}/segmentation/summary`);
    segSummaryData = await res.json();

    const kmScore = segSummaryData.metrics.kmeans.silhouette_score;
    const hScore = segSummaryData.metrics.hierarchical.silhouette_score;

    document.getElementById('seg-km-score').textContent = kmScore;
    document.getElementById('seg-h-score').textContent = hScore;

    // Populate Segment Filter dropdown
    const filterSelect = document.getElementById('segment-filter');
    filterSelect.innerHTML = '<option value="">All Customer Segments</option>';
    
    segSummaryData.cluster_summary.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c.segment_name;
        opt.textContent = `${c.segment_name} (${c.customer_count} customers)`;
        filterSelect.appendChild(opt);
    });

    renderOverviewCharts();
    renderSegmentationCharts();
}

/* Fetch Customer Directory */
async function fetchCustomerDirectory(segment = '') {
    const url = segment ? `${API_BASE}/segmentation/customers?limit=100&segment=${encodeURIComponent(segment)}` : `${API_BASE}/segmentation/customers?limit=100`;
    const res = await fetch(url);
    const data = await res.json();

    const tbody = document.querySelector('#customer-table tbody');
    tbody.innerHTML = '';

    data.customers.forEach(cust => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><code>${cust.customer_id}</code></td>
            <td><strong>${cust.customer_name}</strong></td>
            <td><span class="badge-tag">${cust.segment_name}</span></td>
            <td>${cust.recency_days}</td>
            <td>${cust.frequency_orders}</td>
            <td>$${cust.monetary_sales.toLocaleString('en-US', {minimumFractionDigits: 2})}</td>
            <td>$${cust.avg_order_value.toLocaleString('en-US', {minimumFractionDigits: 2})}</td>
            <td>${(cust.avg_discount * 100).toFixed(1)}%</td>
        `;
        tbody.appendChild(tr);
    });
}

function handleSegmentFilter(e) {
    fetchCustomerDirectory(e.target.value);
}

/* Fetch Forecasting Predictions */
async function fetchForecastingPredictions() {
    const res = await fetch(`${API_BASE}/forecasting/predictions`);
    fcstPredictionsData = await res.json();
    renderForecastChart();
}

/* Fetch Forecasting Metrics */
async function fetchForecastingMetrics() {
    const res = await fetch(`${API_BASE}/forecasting/metrics`);
    fcstMetricsData = await res.json();
    renderEvaluationTableAndCharts();
}

/* Fetch Report */
async function loadReport(reportName) {
    const box = document.getElementById('report-content-box');
    box.innerHTML = '<div class="loading-spinner"><i class="fa-solid fa-spinner fa-spin"></i> Loading report...</div>';

    try {
        const res = await fetch(`${API_BASE}/reports/${reportName}`);
        const data = await res.json();
        box.innerHTML = marked.parse(data.content);
    } catch (e) {
        box.innerHTML = `<p style="color:red;">Failed to load report: ${e}</p>`;
    }
}

/* Rendering Charts */
function renderOverviewCharts() {
    if (!fcstPredictionsData || !segSummaryData) return;

    // 1. Overview Sales Trend Chart
    const ctxSales = document.getElementById('overviewSalesChart').getContext('2d');
    const histData = fcstPredictionsData.data.filter(d => d.y !== null);

    if (charts.overviewSales) charts.overviewSales.destroy();
    charts.overviewSales = new Chart(ctxSales, {
        type: 'line',
        data: {
            labels: histData.map(d => d.ds.substring(0, 7)),
            datasets: [{
                label: 'Monthly Sales ($)',
                data: histData.map(d => d.y),
                borderColor: '#6366f1',
                backgroundColor: 'rgba(99, 102, 241, 0.1)',
                fill: true,
                tension: 0.3,
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#9ca3af' } },
                y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#9ca3af' } }
            }
        }
    });

    // 2. Overview Segment Pie Chart
    const ctxPie = document.getElementById('overviewSegmentChart').getContext('2d');
    const clusters = segSummaryData.cluster_summary;

    if (charts.overviewPie) charts.overviewPie.destroy();
    charts.overviewPie = new Chart(ctxPie, {
        type: 'doughnut',
        data: {
            labels: clusters.map(c => c.segment_name),
            datasets: [{
                data: clusters.map(c => c.pct_sales),
                backgroundColor: ['#6366f1', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { color: '#9ca3af', font: { family: 'Plus Jakarta Sans' } } }
            }
        }
    });
}

function renderSegmentationCharts() {
    if (!segSummaryData) return;
    const clusters = segSummaryData.cluster_summary;

    // Segment Revenue Bar Chart
    const ctxRev = document.getElementById('segRevenueChart').getContext('2d');
    if (charts.segRevenue) charts.segRevenue.destroy();
    charts.segRevenue = new Chart(ctxRev, {
        type: 'bar',
        data: {
            labels: clusters.map(c => c.segment_name),
            datasets: [{
                label: 'Total Sales ($)',
                data: clusters.map(c => c.total_monetary),
                backgroundColor: ['#6366f1', '#10b981', '#f59e0b', '#ec4899'],
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { display: false }, ticks: { color: '#9ca3af' } },
                y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#9ca3af' } }
            }
        }
    });

    // Segment RFM Comparison Chart
    const ctxRfm = document.getElementById('segRfmChart').getContext('2d');
    if (charts.segRfm) charts.segRfm.destroy();
    charts.segRfm = new Chart(ctxRfm, {
        type: 'bar',
        data: {
            labels: clusters.map(c => c.segment_name),
            datasets: [
                { label: 'Avg Recency (Days)', data: clusters.map(c => c.mean_recency), backgroundColor: '#f59e0b', borderRadius: 6 },
                { label: 'Avg Frequency (Orders)', data: clusters.map(c => c.mean_frequency * 10), backgroundColor: '#10b981', borderRadius: 6 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom', labels: { color: '#9ca3af' } } },
            scales: {
                x: { grid: { display: false }, ticks: { color: '#9ca3af' } },
                y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#9ca3af' } }
            }
        }
    });
}

function renderForecastChart() {
    if (!fcstPredictionsData) return;
    const records = fcstPredictionsData.data;

    const titleEl = document.getElementById('forecast-chart-title');
    const badgeEl = document.getElementById('forecast-model-badge');

    titleEl.innerHTML = `<i class="fa-solid fa-chart-line"></i> ${currentForecastModel} 12-Month Sales Forecast (2018)`;
    badgeEl.textContent = `${currentForecastModel} Model`;

    const ctx = document.getElementById('forecastChart').getContext('2d');
    if (charts.forecast) charts.forecast.destroy();

    const labels = records.map(r => r.ds.substring(0, 7));
    const actuals = records.map(r => r.y);

    let datasets = [{
        label: 'Historical Actual Sales',
        data: actuals,
        borderColor: '#9ca3af',
        backgroundColor: 'rgba(156, 163, 175, 0.1)',
        borderWidth: 2,
        pointRadius: 3
    }];

    if (currentForecastModel === 'Prophet') {
        datasets.push({
            label: 'Prophet Forecast (yhat)',
            data: records.map(r => r.prophet_yhat),
            borderColor: '#6366f1',
            backgroundColor: 'rgba(99, 102, 241, 0.15)',
            borderWidth: 3,
            fill: false,
            tension: 0.3
        });
    } else if (currentForecastModel === 'XGBoost') {
        datasets.push({
            label: 'XGBoost Forecast (yhat)',
            data: records.map(r => r.xgboost_yhat),
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.15)',
            borderWidth: 3,
            fill: false,
            tension: 0.2
        });
    } else if (currentForecastModel === 'Random Forest') {
        datasets.push({
            label: 'Random Forest Forecast (yhat)',
            data: records.map(r => r.rf_yhat),
            borderColor: '#f59e0b',
            backgroundColor: 'rgba(245, 158, 11, 0.15)',
            borderWidth: 3,
            fill: false,
            tension: 0.2
        });
    } else {
        // Combined comparison
        datasets.push({ label: 'Prophet', data: records.map(r => r.prophet_yhat), borderColor: '#6366f1', borderWidth: 2, tension: 0.3 });
        datasets.push({ label: 'XGBoost', data: records.map(r => r.xgboost_yhat), borderColor: '#10b981', borderWidth: 2, tension: 0.2 });
        datasets.push({ label: 'Random Forest', data: records.map(r => r.rf_yhat), borderColor: '#f59e0b', borderWidth: 2, tension: 0.2 });
    }

    charts.forecast = new Chart(ctx, {
        type: 'line',
        data: { labels, datasets },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'top', labels: { color: '#9ca3af' } }
            },
            scales: {
                x: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#9ca3af' } },
                y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#9ca3af' } }
            }
        }
    });
}

function renderEvaluationTableAndCharts() {
    if (!fcstMetricsData) return;

    const tbody = document.querySelector('#eval-metrics-table tbody');
    tbody.innerHTML = '';

    const bestModel = fcstMetricsData.best_performing_model;
    const metricsMap = fcstMetricsData.model_metrics;

    Object.keys(metricsMap).forEach(modelName => {
        const m = metricsMap[modelName];
        const isBest = modelName === bestModel;
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><strong>${modelName} ${isBest ? '<i class="fa-solid fa-crown" style="color:#f59e0b; margin-left:4px;"></i>' : ''}</strong></td>
            <td>$${m.MAE.toLocaleString('en-US', {minimumFractionDigits: 2})}</td>
            <td>$${m.RMSE.toLocaleString('en-US', {minimumFractionDigits: 2})}</td>
            <td><strong style="color: ${m.R2 > 0.6 ? '#10b981' : '#f59e0b'}">${m.R2}</strong></td>
            <td>${m.MAPE_pct}%</td>
            <td><span class="badge-tag ${isBest ? 'gold' : ''}">${isBest ? 'Best Performer' : 'Evaluated'}</span></td>
        `;
        tbody.appendChild(tr);
    });

    // Error Bar Chart
    const ctxErr = document.getElementById('evalErrorChart').getContext('2d');
    const models = Object.keys(metricsMap);

    if (charts.evalErr) charts.evalErr.destroy();
    charts.evalErr = new Chart(ctxErr, {
        type: 'bar',
        data: {
            labels: models,
            datasets: [
                { label: 'RMSE ($)', data: models.map(m => metricsMap[m].RMSE), backgroundColor: '#6366f1', borderRadius: 6 },
                { label: 'MAE ($)', data: models.map(m => metricsMap[m].MAE), backgroundColor: '#8b5cf6', borderRadius: 6 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom', labels: { color: '#9ca3af' } } },
            scales: {
                x: { grid: { display: false }, ticks: { color: '#9ca3af' } },
                y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#9ca3af' } }
            }
        }
    });

    // R2 Score Bar Chart
    const ctxR2 = document.getElementById('evalR2Chart').getContext('2d');
    if (charts.evalR2) charts.evalR2.destroy();
    charts.evalR2 = new Chart(ctxR2, {
        type: 'bar',
        data: {
            labels: models,
            datasets: [{
                label: 'R² Score',
                data: models.map(m => metricsMap[m].R2),
                backgroundColor: models.map(m => m === bestModel ? '#10b981' : '#f59e0b'),
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { display: false }, ticks: { color: '#9ca3af' } },
                y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#9ca3af' }, min: 0, max: 1 }
            }
        }
    });
}
